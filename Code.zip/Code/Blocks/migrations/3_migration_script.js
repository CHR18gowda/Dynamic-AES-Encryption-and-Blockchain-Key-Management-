const FileExport = artifacts.require("AccessRequest")

module.exports = function (deployer){
    deployer.deploy(FileExport)
}